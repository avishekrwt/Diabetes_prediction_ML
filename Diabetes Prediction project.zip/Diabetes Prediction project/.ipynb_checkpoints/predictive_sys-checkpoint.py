import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler

# Load the trained model
loaded_model = pickle.load(open('C:/Users/abhis/Downloads/Diabetes Dataset/trained_model.sav', 'rb'))

# New input data for prediction
input_data = (4, 110, 92, 0, 0, 37.6, 0.191, 30)

# Convert input_data to numpy array and reshape for prediction
input_data_as_numpy_array = np.asarray(input_data)
input_data_reshaped = input_data_as_numpy_array.reshape(1, -1)

# Load the scaler used during training
scaler = pickle.load(open('C:/Users/abhis/Downloads/Diabetes Dataset/scaler.sav', 'rb'))

# Standardize the input data using the loaded scaler
std_input_data = scaler.transform(input_data_reshaped)

# Predict using the loaded model
prediction = loaded_model.predict(std_input_data)

# Output the prediction
if prediction[0] == 0:
    print('The person is not diabetic')
else:
    print('The person is diabetic')
