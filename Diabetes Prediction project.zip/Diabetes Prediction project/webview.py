import numpy as np
import pickle
import streamlit as st

# Load the trained model
loaded_model = pickle.load(open('C:/Users/abhis/Music/Diabetes Prediction project/trained_model.sav', 'rb'))

# Creating a function for input
def diabetes_predict(input_data):
    input_data_as_numpy_array = np.asarray(input_data)
    input_data_reshaped = input_data_as_numpy_array.reshape(1, -1)

    scaler = pickle.load(open('C:/Users/abhis/Music/Diabetes Prediction project/scaler.sav', 'rb'))

    std_input_data = scaler.transform(input_data_reshaped)

    prediction = loaded_model.predict(std_input_data)

    # Output of the prediction
    if prediction[0] == 0:
        return 'The person is not diabetic'
    else:
        return 'The person is diabetic'

# Streamlit section
def main():
    # Title
    st.title('Diabetes Prediction')
    st.write('Enter the details below to predict if a person has diabetes or not.')
    st.markdown("""_*Please note that this is a "Prediction" and not an Acutal Diagnosis*_""")
    
    st.markdown(
        """
        <style>
        .stApp {
            background-image: url("https://gomohealth.com/wp-content/uploads/2019/08/diabetes-blood-surgar-check-gradient-background.jpg");
            background-size: cover;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Gathering input data from user
    Pregnancies = st.number_input('Number of Pregnancies',min_value=0,max_value=17)
    Glucose = st.text_input('Glucose Level')
    BloodPressure = st.text_input('Blood Pressure Value')
    SkinThickness = st.text_input('Skin Thickness Value')
    Insulin = st.text_input('Insulin Level')
    BMI = st.text_input('BMI Value')
    DiabetesPedigreeFunction = st.text_input('Diabetes Pedigree Function Value')
    Age = st.number_input('Age of the Person', min_value=1, max_value=120)


    # Code for prediction
    diagnosis = ''

    # Creating a button for confirmation
    if st.button('Diagnosis Result'):
        if (Pregnancies and Glucose and BloodPressure and SkinThickness and Insulin and BMI and DiabetesPedigreeFunction and Age):
            input_data = [float(Pregnancies), float(Glucose), float(BloodPressure), float(SkinThickness), float(Insulin), float(BMI), float(DiabetesPedigreeFunction), float(Age)]
            diagnosis = diabetes_predict(input_data)
        else:
            diagnosis = 'Please enter all the required fields.'

    st.success(diagnosis)

if __name__ == '__main__':
    main()